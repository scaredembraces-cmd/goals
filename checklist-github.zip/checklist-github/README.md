# $20k/mo AI Automation Checklist

## How to deploy (FREE in 3 minutes)

### Step 1 — Put it on GitHub
1. Go to [github.com](https://github.com) and sign up free
2. Click the **+** button → **New repository**
3. Name it `checklist` (or anything you want)
4. Make sure it's set to **Public**
5. Click **Create repository**
6. Click **uploading an existing file**
7. Drag in the `index.html` file → click **Commit changes**

### Step 2 — Turn on GitHub Pages (free hosting)
1. In your repo, click **Settings**
2. Scroll down to **Pages** in the left sidebar
3. Under **Branch**, select `main` → click **Save**
4. Wait 60 seconds → your site is live at:
   `https://YOUR-USERNAME.github.io/checklist`

### Step 3 — Save & share your progress
- Check off items as you complete them
- Hit the **💾 Save & Share** button
- Copy the link → open it on any device

That's it. No code, no terminal, no installs.
